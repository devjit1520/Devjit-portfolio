import { motion } from "framer-motion";
import {
  FaGithub,
  FaLinkedin,
  FaInstagram,
  FaArrowRight,
} from "react-icons/fa";

function Hero() {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center pt-20 bg-gradient-to-br
    from-slate-950
    via-slate-900
    to-blue-950"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">

          {/* Left Side */}
          <motion.div
            initial={{ opacity: 0, x: -80 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
              <div className="inline-flex items-center gap-2 mb-8 bg-green-100/10 border border-green-100/20 px-4 py-2 rounded-full">
              <span className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></span>
              <span >
                Available for Work & Freelance
              </span>
              </div>
            
            <p className="text-blue-500 text-lg mb-4">
              Hey ,  I'm
            </p>

            <h1 className="text-5xl md:text-7xl font-bold mb-4">
              Devjit Mondal
            </h1>

            <h2 className="text-3xl md:text-4xl text-slate-300 mb-6">
              Frontend Developer
            </h2>

            <p className="text-slate-400 text-lg leading-8 max-w-xl mb-8">
             Frontend Developer specializing in React.js, Tailwind CSS,
            and JavaScript. <br /> I create fast, responsive, and user-friendly web experiences
            with clean code and modern design principles.
            </p>

            <div className="flex flex-wrap gap-3 mt-8 mb-8">

              <span
                className="
                px-4 py-2
                rounded-full
                bg-blue-500/10
                border border-blue-500/20
                text-blue-400
                text-sm
                hover:scale-105
                transition
                "
              >
                ⚛ React.js
              </span>

              <span
                className="
                px-4 py-2
                rounded-full
                bg-cyan-500/10
                border border-cyan-500/20
                text-cyan-400
                text-sm
                hover:scale-105
                transition
                "
              >
                🎨 Tailwind CSS
              </span>

              <span
                className="
                px-4 py-2
                rounded-full
                bg-yellow-500/10
                border border-yellow-500/20
                text-yellow-400
                text-sm
                hover:scale-105
                transition
                "
              >
                🟨 JavaScript
              </span>

              <span
                className="
                px-4 py-2
                rounded-full
                bg-orange-500/10
                border border-orange-500/20
                text-orange-400
                text-sm
                hover:scale-105
                transition
                "
              >
                🔥 WordPress
              </span>

            </div>

            {/* Buttons */}
            {/* <div className="flex flex-wrap gap-4 mb-8">
              <a
                href="#projects"
                className="bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-xl flex items-center gap-3 transition"
              >
                View Projects
                <FaArrowRight />
              </a>

              <a
                href="/resume.pdf"
                download
                className="border border-slate-700 hover:border-blue-500 px-8 py-4 rounded-xl transition"
              >
                Download CV
              </a>
            </div> */}

            

            {/* Social Links */}
            {/* <div className="flex gap-6 text-2xl">
              <a
                href="https://github.com/yourusername"
                target="_blank"
                rel="noreferrer"
                className="hover:text-blue-500 transition"
              >
                <FaGithub />
              </a>

              <a
                href="https://linkedin.com/in/yourusername"
                target="_blank"
                rel="noreferrer"
                className="hover:text-blue-500 transition"
              >
                <FaLinkedin />
              </a>

              <a
                href="https://instagram.com/yourusername"
                target="_blank"
                rel="noreferrer"
                className="hover:text-blue-500 transition"
              >
                <FaInstagram />
              </a>
            </div> */}
          </motion.div>

          {/* Right Side */}
          <motion.div
            initial={{ opacity: 0, x: 80 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center"
            
          >
            <div className="relative">

              {/* Blue Glow */}
              <div className="absolute inset-0 bg-blue-500 blur-[120px] opacity-20 rounded-full"></div>

              {/* Profile Image */}
              

              <motion.div
                    animate={{
                      y: [0, -15, 0],
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: 3,
                    }}
                  >
                    ⚛ React
              </motion.div>

              

              <img
                src="..\src\assets\devjit.png"
                alt="Profile"
                className="
                w-[320px]
                h-[320px]
                rounded-full
                object-cover
                border-4
                border-slate-700
                shadow-[0_0_80px_rgba(59,130,246,0.3)]
                
                "

                
                // className="relative w-[280px] h-[280px] lg:w-[320px] lg:h-[320px] object-fill rounded-full border-4 border-slate-800 shadow-2xl"
              />

              <motion.div
              
                    animate={{
                      y: [0, -15, 0],
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: 3,
                    }}
                  >
                   🟨 JavaScript
              </motion.div>

              
            </div>
            <motion.div
                    animate={{
                      y: [0, -15, 0],
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: 3,
                    }} 
                   

                   
                  >
                   🎨 Tailwind CSS

              </motion.div>
            
            
          </motion.div>

          

        </div>
      </div>
    </section>
  );
}

export default Hero;